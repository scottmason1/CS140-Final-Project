package project;

public interface Instruction {

	void execute(int arg, int indirLvl);
}
